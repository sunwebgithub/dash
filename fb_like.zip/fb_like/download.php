<?php
$url=$_POST['url'];
if($url=="URL OF THE PAGE THAT IS TO BE LIKED")
{
    echo "DOWNLOAD LINK";//make sure download link is a fourced download
}
else
{
    echo "NULL";
}
?>